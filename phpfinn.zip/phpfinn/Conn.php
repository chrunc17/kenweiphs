<?php

$connection = mysql_Connect('localhost','root',"");
		
		if(!$connection){
		die("database Connection Failed".mysql_error());
		}
		mysql_select_db("Projsad",$connection);
		

?>